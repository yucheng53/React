import 'bootstrap/dist/css/bootstrap.min.css';
import './App.css';
import Userform from './components/Userform';

function App() {
  return (
    <div className='container-sm'>
      <Userform />
    </div>
  );
}

export default App;
