import 'bootstrap/dist/css/bootstrap.min.css';
import './App.css';
import React,{ useState,useEffect } from 'react';
import Pokeman from './component.js/Pokeman';



function App() {

  return (
    <div className="App">
      <Pokeman />
    </div>
  );
}

export default App;
